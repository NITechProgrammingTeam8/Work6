# Dimensions Overlay

Show or hide the dimensions for all three axes. 

![Dimensions Overlay Example](images/menu-dimover.png)

This overlay appears on all Mesh objects, not just ProBuilder Meshes.