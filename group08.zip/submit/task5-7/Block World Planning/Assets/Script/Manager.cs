﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{

    public GameObject planObj;

    public void Remove()
    {
        Destroy(planObj);
        Destroy(this.gameObject);
    }
}
