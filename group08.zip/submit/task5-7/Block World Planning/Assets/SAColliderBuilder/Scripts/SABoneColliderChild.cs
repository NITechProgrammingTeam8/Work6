﻿//----------------------------------------------
// SABoneCollider
// Copyright (c) 2014 Stereoarts Nora
//----------------------------------------------
using UnityEngine;

public class SABoneColliderChild : MonoBehaviour
{
}
